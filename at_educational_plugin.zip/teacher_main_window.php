<!DOCTYPE HTML>
<html>

<head>
    <meta charset="UTF-8">
</head>

<body>

    <?php
    session_start();
    $userid = $_GET["username"];
    ?>

    <head>
        <title>Meniu</title>
    </head>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">

    <style>
        body {
            /* background: #defcf9;  */
            background-image: linear-gradient(#cadefc, #defcf9);
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-size: auto;
            font-family: Poppins, sans-serif;
            font-size: 16px;
            line-height: 25.6px;
            margin: 0px;
            padding: 10px;
        }

        h1,
        h2,
        h3,
        h4 {
            font-family: Ubuntu, sans-serif;
            color: white;
            text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
            text-align: center;
        }

        .menu {
            background: #cadefc;
            text-align: center;
            width: 382px;
            overflow: hidden;
            margin: auto;
            margin: 20 0 0 450px;
            padding: 80px;
            display: block;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .button {
            width: 100%;
            background-color: #c3bef0;
            color: black;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
        }

        .button:hover {
            box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
            background-color: #cca8e9;
        }
    </style>

    <h1>Meniu</h1>
    <div class="menu">
        <form action="students_displaylist.php?username=<?php echo $userid ?>" method="post">
            <input type="submit" class="button" name="view_logins" value="Peržiūrėti mokinių prisijungimus" />
        </form>
        <form action="students_results.php?username=<?php echo $userid ?>" method="post">
            <input type="submit" class="button" name="view_stud_res" value="Peržiūrėti mokinių rezultatus" />
        </form>
        <form action="students_top_ten.php?username=<?php echo $userid ?>&occupation=Mokytojas" method="post">
            <input type="submit" class="button" name="view_best_stud" value="Peržiūrėti TOP 10 mokinių rezultatų" />
        </form>
        <form action="students_addentry.php?username=<?php echo $userid ?>" method="post">
            <input type="submit" class="button" name="add_new" value="Pridėti naują mokinį" />
        </form>
        <form action="logout_page.php">
            <input type="submit" class="button" name="logout" value="Atsijungti">
        </form>
    </div>

</body>

</html>