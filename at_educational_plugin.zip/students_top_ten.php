<!DOCTYPE HTML>
<?php
session_start();
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php');
global $wpdb;
$tablename3 = $table_prefix . "playsession";
$tablename2 = $table_prefix . "students";
$userid = $_GET["username"];
$usertype = $_GET["occupation"];
?>


<head>
	<title>Mokinių prisijungimai</title>
</head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">

<style>
	body {
		/* background: #defcf9;  */
		background-image: linear-gradient(#cadefc, #defcf9);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: auto;
		font-family: Poppins, sans-serif;
		font-size: 16px;
		line-height: 25.6px;
		margin: 0px;
		padding: 10px;
	}

	h1,
	h2,
	h3,
	h4 {
		font-family: Ubuntu, sans-serif;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
		text-align: center;
	}

	table {
		border-collapse: collapse;
		width: 100%;
	}

	th,
	td {
		padding: 8px;
		text-align: left;
		border-bottom: 1px solid #cca8e9;
	}

	tr:hover {
		background-color: #c3bef0;
	}

	.button {
		width: 25%;
		background-color: #c3bef0;
		color: black;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
	}

	.button:hover {
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
		background-color: #cca8e9;
	}

	.Lentele {
		background: #cadefc;
		text-align: center;
		overflow: hidden;
		margin: auto;
		/* margin: 20 0 0 450px; */
		padding: 50px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}
</style>

<div class="Lentele">
	<h1>TOP 10 geriausių mokinių rezultatai</h1>

	<table width='100%' border='1' style='border-collapse: collapse;'>
		<tr>
			<th>Nr.</th>
			<th>Prisijungimo vardas</th>
			<th>Rezultatas</th>
		</tr>

		<?php
		// Select records
		$entriesList = $wpdb->get_results("SELECT * FROM " . $tablename3 . " order by result + 0 desc limit 10");
		if (count($entriesList) > 0) {
			$count = 1;
			foreach ($entriesList as $entry) {
				$id = $entry->id;
				$s_id = $entry->student_id;
				$stud_username  = $wpdb->get_var("SELECT username FROM " . $tablename2 . " WHERE id ='$s_id'");
				$rez = $entry->result;

				echo "<tr>
		    	<td>" . $count . "</td>
				<td>" . $stud_username . "</td>
		    	<td>" . $rez . "</td>
		    </tr>
		    ";

				$count++;
			}
		} else {
			echo "<tr><td colspan='5'>Nėrą įrašų</td></tr>";
		}

		?>
	</table>
</div>

<?php
// redirect back to the teacher's page
if ($usertype === "Mokytojas") {
?>
	<form action="teacher_main_window.php?username=<?php echo $userid ?>" method="post">
		<input type="submit" name="teacher_window" class="button" value="Grįžti atgal" />
	</form>
<?php
} else {
	// redirect back to the student's page
	$studscore = $_GET["score"];
?>
	<form action="student_gameover.php?username=<?php echo $userid ?>&score=<?php echo $studscore ?>" method="post">
		<input type="submit" name="student_window" class="button" value="Grįžti atgal" />
	</form>
<?php
}
