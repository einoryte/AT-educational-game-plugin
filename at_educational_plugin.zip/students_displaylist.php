<?php
session_start();

//rodoma tik tuos įrašus, kurie buvo kurti to mokytojo.
//Mokytojas kitų mokytojų mokinių prisijungimų neturėtų galėt žiūrėt

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php');
global $wpdb;

$userid = $_GET["username"];

$tablename2 = $table_prefix . "students";
$tablename = $table_prefix . "teachers";
$tablename3 = $table_prefix . "playsession";
$teachers_id = $wpdb->get_var("SELECT id FROM " . $tablename . " WHERE username ='$userid'");

// Delete record
if (isset($_GET['delid'])) {
	$delid = $_GET['delid'];
	$wpdb->query("DELETE FROM " . $tablename3 . " WHERE student_id=" . $delid);
	$wpdb->query("DELETE FROM " . $tablename2 . " WHERE id=" . $delid);
}
?>

<head>
	<title>Mokinių prisijungimai</title>
</head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">

<style>
	body {
		/* background: #defcf9;  */
		background-image: linear-gradient(#cadefc, #defcf9);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: auto;
		font-family: Poppins, sans-serif;
		font-size: 16px;
		line-height: 25.6px;
		margin: 0px;
		padding: 10px;
	}

	h1,
	h2,
	h3,
	h4 {
		font-family: Ubuntu, sans-serif;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
		text-align: center;
	}

	table {
		border-collapse: collapse;
		width: 100%;
	}

	th,
	td {
		padding: 8px;
		text-align: left;
		border-bottom: 1px solid #cca8e9;
	}

	tr:hover {
		background-color: #c3bef0;
	}

	.button {
		width: 25%;
		background-color: #c3bef0;
		color: black;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
	}

	.button:hover {
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
		background-color: #cca8e9;
	}


	.Lentele {
		background: #cadefc;
		text-align: center;
		overflow: hidden;
		margin: auto;
		/* margin: 20 0 0 450px; */
		padding: 50px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}

	.rikiavimas {
		background: #defcf9;
		text-align: center;
		overflow: hidden;
		/* margin: auto; */
		/* margin: 20 0 0 450px; */
		padding: 30px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}
</style>



<div class="rikiavimas">
	<h1>Keisti duomenų rodymą:</h1>
	<form method='post' action=''>
		<label for="choose_sort_by">Rikiuoti pagal laukelį:</label>
		<select name="select_catalog2" id="select_catalog2">
			<option value="id">Nr.</option>
			<option value="username">Prisijungimo vardas</option>
		</select>
		<label for="choose_sort_type">Tvarka:</label>
		<select name="select_catalog3" id="select_catalog3">
			<option value="asc">Didėjanti</option>
			<option value="desc">Mažėjanti</option>
		</select>
		<input type="submit" class="button" name="submit" value="Pateikti">
	</form>
</div>

<div class="Lentele">
	<h1>Mokinių prisijungimo duomenys</h1>
	<table width='100%' border='1' style='border-collapse: collapse;'>
		<tr>
			<th>Nr.</th>
			<th>Prisijungimo vardas</th>
			<th>Slaptažodis</th>
			<th>&nbsp;</th>
		</tr>

		<?php
		$orderby = $_POST['select_catalog2'];
		$order_type = $_POST['select_catalog3'];

		// Select records

		if (isset($_POST['select_catalog2'])  && isset($_POST['select_catalog3']) && isset($_POST['submit'])) {
			$entriesList = $wpdb->get_results("SELECT * FROM " . $tablename2 . " WHERE teacher_id ='$teachers_id' order by $orderby $order_type");
		} else {
			$entriesList = $wpdb->get_results("SELECT * FROM " . $tablename2 . " WHERE teacher_id ='$teachers_id'");
		}
		if (count($entriesList) > 0) {
			$count = 1;
			foreach ($entriesList as $entry) {
				$id = $entry->id;
				$uname = $entry->username;
				$user_password = $entry->user_password;

				echo "<tr>
		    	<td>" . $id . "</td>
		    	<td>" . $uname . "</td>
		    	<td>" . $user_password . "</td>
		    	<td><a href='?username=" . $userid . "&delid=" . $id ."'>Ištrinti</a></td>
		    </tr>
		    ";
				$count++;
			}
		} else {
			echo "<tr><td colspan='5'>Nėrą įrašų</td></tr>";
		}

		?>
	</table>
</div>

<form action="teacher_main_window.php?username=<?php echo $userid ?>" method="post">
	<input type="submit" name="teacher_window" class="button" value="Grįžti atgal" />
</form>