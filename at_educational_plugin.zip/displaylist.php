<?php
global $wpdb;

$tablename = $wpdb->prefix . "teachers";
$tablename2 = $wpdb->prefix . "students";
$tablename3 = $wpdb->prefix . "playsession";


// Delete record
if (isset($_GET['delid'])) {
	$delid = $_GET['delid'];
	$usernames_id = $wpdb->get_col("SELECT id FROM " . $tablename2 . " WHERE teacher_id =" . $delid);
	$usernames_id = implode( ',', array_map( 'absint', $usernames_id ) );

	$wpdb->query("DELETE FROM " . $tablename3 . " WHERE student_id IN ($usernames_id)");

	$wpdb->query("DELETE FROM " . $tablename2 . " WHERE teacher_id=" . $delid);

	$wpdb->query("DELETE FROM " . $tablename . " WHERE id=" . $delid);

}
?>
<h1>Mokytojų prisijungimo duomenys</h1>

<table width='100%' border='1' style='border-collapse: collapse;'>
	<tr>
		<th>Nr.</th>
		<th>Mokytojo prisijungimo vardas</th>
		<th>Slaptažodis</th>
		<th>&nbsp;</th>
	</tr>
	<?php
	// Select records
	$entriesList = $wpdb->get_results("SELECT * FROM " . $tablename . " order by id asc");
	if (count($entriesList) > 0) {
		$count = 1;
		foreach ($entriesList as $entry) {
			$id = $entry->id;
			$uname = $entry->username;
			$user_password = $entry->user_password;

			echo "<tr>
		    	<td>" . $id . "</td>
		    	<td>" . $uname . "</td>
		    	<td>" . $user_password . "</td>
		    	<td><a href='?page=allentries&delid=" . $id . "'>Ištrinti</a></td>
		    </tr>
		    ";
			$count++;
		}
	} else {
		echo "<tr><td colspan='5'>Nėrą įrašų</td></tr>";
	}


	?>
</table>