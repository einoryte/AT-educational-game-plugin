<?php

global $wpdb;

// Add record
if (isset($_POST['but_submit'])) {

	$uname = $_POST['txt_uname'];
	$user_password = $_POST['txt_password'];
	$tablename = $wpdb->prefix . "teachers";

	if ($uname != '' && $user_password != '') {
		$check_data = $wpdb->get_results("SELECT * FROM " . $tablename . " WHERE username='" . $uname . "' ");
		if (count($check_data) == 0) {
			$insert_sql = "INSERT INTO " . $tablename . "(username,user_password) values('" . $uname . "','" . $user_password . "') ";
			$wpdb->query($insert_sql);
			echo "Prisijungimas sukurtas ir išsaugotas";
		} else {
			echo "Toks mokytojo prisijungimo vardas jau egzistuoja, sukurkite naują.";
		}
	} else {
		echo "Užpildykite visus laukelius, kad sukurti prisijungimą mokytojui.";
	}
}

?>
<h1>Sukurkite prisijungimą naujam mokytojui:</h1>
<form method='post' action=''>
	<table>
		<tr>
			<td>Naujo mokytojo prisijungimo vardas</td>
			<td><input type='text' name='txt_uname'></td>
		</tr>
		<tr>
			<td>Naujo mokytojo slaptažodis</td>
			<td><input type='text' name='txt_password'></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type='submit' name='but_submit' value='Pridėti'></td>
		</tr>
	</table>
</form>