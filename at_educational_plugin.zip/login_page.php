<!DOCTYPE HTML>  
<html>
<body>

<?php
session_start();
// Getting info about occupation from initial page
$occupation = $_GET["occupation"];	
$uname = $psw = "";

require_once( dirname( dirname( dirname( dirname( __FILE__ )))) . '/wp-load.php' );
global $wpdb;
$tablename2 = $table_prefix."students";
$tablename = $table_prefix."teachers";
?>


<head>
<title>Prisijungimas</title>
</head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">

<style>
body {
  /* background: #defcf9;  */
  background-image: linear-gradient(#cadefc, #defcf9);
  background-attachment: fixed;
  background-repeat: no-repeat;
  background-size: auto;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  line-height: 25.6px;
  margin: 0px;
  padding: 10px;
}

h1, h2, h3, h4 {
  font-family: Ubuntu, sans-serif;
  color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
  text-align: center;
}

.login {
  background: #cadefc;
  text-align: center;
  		width: 382px;  
        overflow: hidden;  
        margin: auto;   
        margin: 20 0 0 450px;   
        padding: 80px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.info{
width: 75%;
  padding: 12px 20px;
  margin: auto;
  box-sizing: border-box;
  border: 3px solid #c3bef0;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
  border-radius: 6px;
  display: block;
}

.info:focus {
  border: 3px solid #cca8e9;
}

.button{
	width: 100%;
  background-color: #c3bef0;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.10), 0 17px 50px 0 rgba(0,0,0,0.05);
}

.button:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
  background-color: #cca8e9;
}
</style>

<form action="" method="post">

<h1>Prisijunkite</h1>
<?php if (strcmp($occupation, "Mokytojas") == 0) { ?> 
    <h4>Įveskite mokytojo prisijungimo duomenis</h4>
<?php }else{ ?>
	<h4>Įveskite mokinio prisijungimo duomenis</h4>
	<?php } ?>
  <div class="login">

    <label for="uname"><b>Prisijungimo vardas</b></label>
    <input type="text" placeholder="Įveskite naudotojo vardą" class="info" name="uname" required>
	<br><br>  
    <label for="psw"><b>Slaptažodis</b></label>
    <input type="password" placeholder="Įveskite slaptažodį" class="info"  name="psw" required>
	<br><br>  
    <input type="submit" class="button" name="submitform" value="Prisijungti" />
  </div>

</form>

<?php
// Checking whether the session is already there or not if
// true then header redirect it to the home page directly 

if (strcmp($occupation, "Mokytojas") == 0){
 if(isset($_SESSION['username']) && isset($_SESSION["teacher_loggedin"]) && $_SESSION["teacher_loggedin"] === true)
  {
	header("Location: teacher_main_window.php?username=" . $_SESSION['username']); 
  }elseif(isset($_SESSION['username']) && isset($_SESSION["student_loggedin"]) && $_SESSION["student_loggedin"] === true){
	session_unset();
	session_destroy(); 
  }
}
  if (strcmp($occupation, "Moksleivis") == 0){
  if(isset($_SESSION['username']) && isset($_SESSION["student_loggedin"]) && $_SESSION["student_loggedin"] === true)
  {
	header("Location: game/index.html?username=" . $_SESSION['username']); 
  }elseif(isset($_SESSION['username']) && isset($_SESSION["teacher_loggedin"]) && $_SESSION["teacher_loggedin"] === true){
	session_unset();
	session_destroy(); 
  }
  }
// Login validation and redirection
if (isset($_POST['submitform'])) { 
    
	if(empty($_POST["uname"])){
		echo '<script>alert("Prašome įvesti naudotojo prisijungimo vardą")</script>';
    } else{
	$user = $_POST['uname'];}

	if(empty($_POST['psw'])){
		echo '<script>alert("Prašome įvesti naudotojo slaptažodį")</script>';
    } else{

	$password = $_POST['psw'];}

	if (strcmp($occupation, "Moksleivis") == 0) {
	// Check student's login	
		$students_psw = $wpdb->get_var("SELECT user_password FROM ".$tablename2." WHERE username ='$user'");
	
		if (strcmp($students_psw, $password) == 0) {

		$_SESSION['username'] = $user;   
		$_SESSION['student_loggedin'] = true;
		// Redirecting to student's page - game
		?>
			<script>
				var username = '<?=$user?>';
				window.location.href="game/index.html?username="+username;
			</script>   	
	
		<?php
		} else {
		// Login failed
		echo '<script>alert("Toks vartotojas studentų duomenų bazėje neegzistuoja. Prašome patikrinti prisijungimo duomenis ir bandyti dar kartą")</script>';
		}
	}
	else {
	// Check teacher's login	
		$teachers_psw = $wpdb->get_var("SELECT user_password FROM ".$tablename." WHERE username ='$user'");
	
		if (strcmp($teachers_psw, $password) == 0) {

			$_SESSION['username'] = $user;
			$_SESSION['teacher_loggedin'] = true;
		// Redirecting to teacher's page - students' database
		?>
			<script>
				var username = '<?=$user?>';
				window.location.href="teacher_main_window.php?username="+username;
			</script>   	
	
		<?php
		} else {
		// Login failed
		echo '<script>alert("Toks vartotojas mokytojų duomenų bazėje neegzistuoja. Prašome patikrinti prisijungimo duomenis ir bandyti dar kartą")</script>';
		}
	}
}

?>

</body>
</html>