<?php
session_start();
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php');
global $wpdb;

//Destroying session
session_unset();
session_destroy();

//Nukreipimas į main page
$tablename4 = $table_prefix . "posts";
$page_id = $wpdb->get_var('SELECT ID FROM ' . $tablename4 . ' WHERE post_content LIKE "%[at_occupation_buttons]%"');
wp_redirect(get_permalink($page_id));
exit();
