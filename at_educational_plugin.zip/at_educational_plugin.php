<?php

/**
 *Plugin Name: AT educational game plugin
 *Description: This is an educational plugin for PHASER game
 *Version: 0.1.0
 *Author: Ainė Paplauskaitė, Teodora Einorytė
 **/

//Teacher and Student buttons for login



function occupation_buttons()
{
	$content = '';
	$content .= '<h3>Pasirinkite prisijungimo būdą</h3>';
	$content .= '<form action="' . plugins_url('at_educational_plugin/login_page.php') . '">';
	$content .= '<input type="submit" name="occupation" class="button" value="Mokytojas" />';
	$content .= '<input type="submit" name="occupation" class="button" value="Moksleivis" />';
	$content .= '</form>';
	$content .= '<form action="' . plugins_url('at_educational_plugin/game/index.html') . '">';
	$content .= '<input type="submit" name="no_login" class="button" value="Žaisti kaip svečias" />';
	$content .= '</form>';
	$content .= '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">';
	$content .= '<style>
	body {
		/* background: #defcf9;  */
		background-image: linear-gradient(#cadefc, #defcf9);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: auto;
		font-family: Poppins, sans-serif;
		font-size: 16px;
		line-height: 25.6px;
		margin: 0px;
		padding: 10px;
	}
	h1,
	h2,
	h3,
	h4 {
		font-family: Ubuntu, sans-serif;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
		text-align: center;
	}
	.button {
		width: 50%;
		background-color: #c3bef0;
		color: black;
		padding: 14px 20px;
		margin: 8px auto;
    display: block;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
	}

	.button:hover {
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
		background-color: #cca8e9;
	}
	</style>';

	return $content;
}

add_shortcode('at_occupation_buttons', 'occupation_buttons');


// Function to create databases for teachers and students

// Create a new table
function managamentsystem_tables()
{
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

	$tablename = $wpdb->prefix . "teachers";
	$sql = "CREATE TABLE $tablename (
	  id mediumint(11) NOT NULL AUTO_INCREMENT,
	  username varchar(20) NOT NULL,
	  user_password varchar(20) NOT NULL,
	  PRIMARY KEY  (id)
	) $charset_collate;";
	dbDelta($sql);


	$tablename2 = $wpdb->prefix . "students";
	$sql2 = "CREATE TABLE $tablename2 (
id mediumint(11) NOT NULL AUTO_INCREMENT,
teacher_id mediumint( 11 ) NOT NULL,
username VARCHAR(20) NOT NULL,
user_password VARCHAR(20) NOT NULL,
FOREIGN KEY (teacher_id) REFERENCES $tablename(id),
PRIMARY KEY  (id)
) $charset_collate;";
	dbDelta($sql2);

	$tablename3 = $wpdb->prefix . "playsession";
	$sql3 = "CREATE TABLE $tablename3 (
id mediumint(11) NOT NULL AUTO_INCREMENT,
student_id mediumint( 11 ) NOT NULL,
result VARCHAR(20) NOT NULL,
times_played mediumint( 11 ) DEFAULT 1, -- laukelis, kuris parodo kelintą kartą studentas žaidžia
date_time DATE DEFAULT (CURRENT_DATE),
FOREIGN KEY (student_id) REFERENCES $tablename2(id),
PRIMARY KEY  (id)
) $charset_collate;";
	dbDelta($sql3);
}
register_activation_hook(__FILE__, 'managamentsystem_tables');


// Add menu for administrator
function managamentsystem_menu()
{

	add_menu_page("Valdymo sistema", "Valdymo sistema", "manage_options", "myplugin", "displayList", plugins_url('/at_educational_plugin/img/icon.png'));
	add_submenu_page("myplugin", "Peržiūrėti mokytojų prisijungimus", "Peržiūrėti mokytojų prisijungimus", "manage_options", "allentries", "displayList");
	add_submenu_page("myplugin", "Pridėti naują mokytoją", "Pridėti naują mokytoją", "manage_options", "addnewentry", "addEntry");
}

add_action("admin_menu", "managamentsystem_menu");



function displayList()
{
	include "displaylist.php";
}

function addEntry()
{
	include "addentry.php";
}

function students_addEntry()
{
	include "students_addentry.php";
}

function students_displayList()
{
	include "students_displaylist.php";
}

function teacher_MainWindow()
{
	include "teacher_main_window.php";
}

function student_Gameover()
{
	include "student_gameover.php";
}

function loginPage()
{
	include "login_page.php";
}
