<?php
session_start();

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php');
global $wpdb;

$tablename = $table_prefix . "teachers";
//getting teacher's username
$userid = $_GET["username"];
//teacher's id
$teachers_id = $wpdb->get_var("SELECT id FROM " . $tablename . " WHERE username ='$userid'");

// Add record
if (isset($_POST['but_submit'])) {

	$uname = $_POST['txt_uname'];
	$user_password = $_POST['txt_password'];
	$tablename2 = $table_prefix . "students";

	if ($uname != '' && $user_password != '') {
		$check_data = $wpdb->get_results("SELECT * FROM " . $tablename2 . " WHERE username = '$uname'");
		if (count($check_data) == 0) {
			$insert_sql = "INSERT INTO " . $tablename2 . " (teacher_id,username,user_password) values('$teachers_id','$uname','$user_password') ";
			$wpdb->query($insert_sql);
			echo '<script>alert("Prisijungimas sukurtas ir išsaugotas")</script>';
		} else {
			echo '<script>alert("Toks mokinio prisijungimo vardas jau egzistuoja, sukurkite naują.")</script>';
		}
	} else {
		echo '<script>alert("Užpildykite visus laukelius, kad sukurti prisijungimą mokiniui")</script>';
	}
}

?>

<head>
	<title>Prisijungimo sukurimas</title>
</head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">


<style>
	body {
		/* background: #defcf9;  */
		background-image: linear-gradient(#cadefc, #defcf9);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: auto;
		font-family: Poppins, sans-serif;
		font-size: 16px;
		line-height: 25.6px;
		margin: 0px;
		padding: 10px;
	}

	h1,
	h2,
	h3,
	h4 {
		font-family: Ubuntu, sans-serif;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
		text-align: center;
	}

	.register {
		background: #cadefc;
		text-align: center;
		width: 382px;
		overflow: hidden;
		margin: auto;
		margin: 20 0 0 450px;
		padding: 80px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}

	.info {
		width: 75%;
		padding: 12px 20px;
		margin: auto;
		box-sizing: border-box;
		border: 3px solid #c3bef0;
		-webkit-transition: 0.5s;
		transition: 0.5s;
		outline: none;
		border-radius: 6px;
		display: block;
	}

	.info:focus {
		border: 3px solid #cca8e9;
	}

	.button {
		width: 100%;
		background-color: #c3bef0;
		color: black;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
	}

	.button:hover {
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
		background-color: #cca8e9;
	}
</style>

<h1>Sukurkite prisijungimą naujam mokiniui:</h1>
<div class="register">
	<form method='post' action=''>

		<label for="txt_uname"><b>Naujo mokinio prisijungimo vardas</b></label>
		<input type='text' class="info" name='txt_uname'>
		<br><br>
		<label for="txt_password"><b>Naujo mokinio slaptažodis</b></label>
		<input type="password" class="info" name='txt_password'>
		<br><br>
		<input type='submit' name='but_submit' class="button" value='Pridėti'>

	</form>
	<form action="teacher_main_window.php?username=<?php echo $userid ?>" method="post">
		<input type="submit" name="teacher_window" class="button" value="Grįžti atgal" />
	</form>
</div>