<!DOCTYPE HTML>
<?php
session_start();
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php');
global $wpdb;
$tablename3 = $table_prefix . "playsession";
$tablename2 = $table_prefix . "students";
?>

<html>

<head>
	<title>Žaidimo pabaiga</title>
</head>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins|Lora">

<style>
	body {
		/* background: #defcf9;  */
		background-image: linear-gradient(#cadefc, #defcf9);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: auto;
		font-family: Poppins, sans-serif;
		font-size: 16px;
		line-height: 25.6px;
		margin: 0px;
		padding: 10px;
	}

	h1,
	h2,
	h3,
	h4 {
		font-family: Ubuntu, sans-serif;
		color: white;
		text-shadow: 1px 1px 2px black, 0 0 25px #98f6ec, 0 0 5px #a86bda;
		text-align: center;
	}

	.menu {
		background: #cadefc;
		text-align: center;
		width: 382px;
		overflow: hidden;
		margin: auto;
		margin: 20 0 0 450px;
		padding: 80px;
		display: block;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	}

	.button {
		width: 100%;
		background-color: #c3bef0;
		color: black;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		border-radius: 4px;
		cursor: pointer;
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.10), 0 17px 50px 0 rgba(0, 0, 0, 0.05);
	}

	.button:hover {
		box-shadow: 0 12px 16px 0 rgba(0, 0, 0, 0.24), 0 17px 50px 0 rgba(0, 0, 0, 0.19);
		background-color: #cca8e9;
	}
</style>

<body>

	<h1>Žaidimas baigtas</h1>

	<h4>Jūsų rezultatas:
		<?php

		// get score
		$studscore = $_GET["score"];
		echo $studscore;

		// get username
		$userid = $_GET["username"];

		// info, if game was played (not just returned from other page)
		$just_lost = $_GET["lostgame"];

		$student_id = $wpdb->get_var("SELECT id FROM " . $tablename2 . " WHERE username ='$userid'");

		$student_times_played = $wpdb->get_var("SELECT MAX(times_played) FROM " . $tablename3 . " WHERE student_id ='$student_id'");
		$student_times_played++;


		// if game played with login, save the result
		if ($userid !== null && trim($userid) !== '' && $userid !== 'null' && $just_lost === 'true') {
			if (!empty($student_times_played)) {
				$insert_sql = "INSERT INTO " . $tablename3 . " (student_id,result,times_played) values('$student_id','$studscore','$student_times_played') ";
				$wpdb->query($insert_sql);
			} else {
				$insert_sql = "INSERT INTO " . $tablename3 . " (student_id,result) values('$student_id','$studscore') ";
				$wpdb->query($insert_sql);
			}
		}

		?>
	</h4>
	<div class="menu">
		<?php
		if ($userid !== null && trim($userid) !== '' && $userid !== 'null') {
		?>

			<form action="students_my_results.php?username=<?php echo $userid ?>&score=<?php echo $studscore ?>" method="post">
				<input type="submit" name="view_logins" class="button" value="Peržiūrėti savo visus rezultatus" />
			</form>
		<?php
		}
		?>

		<form action="students_top_ten.php?username=<?php echo $userid ?>&occupation=Moksleivis&score=<?php echo $studscore ?>" method="post">
			<input type="submit" name="view_logins" class="button" value="Peržiūrėti TOP 10 mokinių rezultatų" />
		</form>

		<form action="game/index.html?username=<?php echo $userid ?>" method="post">
			<input type="submit" name="reloadgame" class="button" value="Žaisti iš naujo">
		</form>
		<?php
		if ($userid !== null && trim($userid) !== '' && $userid !== 'null') {
		?>
			<form action="logout_page.php">
				<input type="submit" name="logout" class="button" value="Atsijungti">
			</form>
		<?php
		} else {
		?>
			<form action="logout_page.php">
				<input type="submit" name="logout" class="button" value="Išeiti">
			</form>
		<?php
		}
		?>
	</div>
</body>

</html>